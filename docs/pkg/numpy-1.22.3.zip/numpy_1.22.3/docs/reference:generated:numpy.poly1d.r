{
  "_content": {},
  "aliases": [],
  "arbitrary": [
    {
      "children": [
        {
          "data": {
            "values": [
              "orphan"
            ]
          },
          "type": "Options"
        }
      ],
      "title": null
    },
    {
      "children": [
        {
          "data": {
            "args0": [],
            "directive_name": "currentmodule",
            "inner": {
              "inline": [
                {
                  "data": {
                    "value": "numpy "
                  },
                  "type": "Words"
                }
              ],
              "inner": []
            }
          },
          "type": "BlockDirective"
        },
        {
          "data": {
            "inline": [
              {
                "data": {
                  "value": "property"
                },
                "type": "Words"
              }
            ],
            "inner": []
          },
          "type": "Paragraph"
        },
        {
          "data": {
            "args0": [],
            "directive_name": "autoproperty",
            "inner": {
              "inline": [
                {
                  "data": {
                    "value": "numpy : : poly1d.r "
                  },
                  "type": "Words"
                }
              ],
              "inner": []
            }
          },
          "type": "BlockDirective"
        }
      ],
      "title": "numpy.poly1d.r"
    }
  ],
  "example_section_data": {
    "children": [],
    "title": null
  },
  "item_file": null,
  "item_line": null,
  "item_type": null,
  "ordered_sections": [],
  "references": null,
  "refs": [],
  "see_also": [],
  "signature": {
    "value": null
  }
}