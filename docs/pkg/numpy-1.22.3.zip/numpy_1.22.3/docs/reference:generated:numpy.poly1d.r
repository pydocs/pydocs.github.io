{
  "_content": {},
  "aliases": [],
  "arbitrary": [
    {
      "children": [
        {
          "data": {
            "values": [
              "orphan"
            ]
          },
          "type": "Options"
        }
      ],
      "title": null
    },
    {
      "children": [
        {
          "data": {
            "argument": "numpy",
            "content": "",
            "name": "currentmodule",
            "options": []
          },
          "type": "BlockDirective"
        },
        {
          "data": {
            "children": [
              {
                "data": {
                  "value": "property"
                },
                "type": "Words"
              }
            ]
          },
          "type": "Paragraph"
        },
        {
          "data": {
            "argument": "numpy::poly1d.r",
            "content": "",
            "name": "autoproperty",
            "options": []
          },
          "type": "BlockDirective"
        }
      ],
      "title": "numpy.poly1d.r"
    }
  ],
  "example_section_data": {
    "children": [],
    "title": null
  },
  "item_file": null,
  "item_line": null,
  "item_type": null,
  "ordered_sections": [],
  "references": null,
  "refs": [],
  "see_also": [],
  "signature": {
    "value": null
  }
}