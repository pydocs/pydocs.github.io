{
  "_content": {},
  "aliases": [],
  "arbitrary": [
    {
      "children": [
        {
          "data": {
            "argument": "../../../../../../numpy/random/_examples/cython/setup.py",
            "content": "",
            "name": "literalinclude",
            "options": [
              [
                "language",
                "python"
              ]
            ]
          },
          "type": "BlockDirective"
        }
      ],
      "title": "setup.py"
    }
  ],
  "example_section_data": {
    "children": [],
    "title": null
  },
  "item_file": null,
  "item_line": null,
  "item_type": null,
  "ordered_sections": [],
  "references": null,
  "refs": [],
  "see_also": [],
  "signature": {
    "value": null
  }
}