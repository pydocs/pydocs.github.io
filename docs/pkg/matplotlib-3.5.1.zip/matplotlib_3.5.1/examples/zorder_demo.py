{
  "children": [
    {
      "data": {
        "ce_status": "execed",
        "entries": [
          {
            "link": {
              "data": "\"\"\"\n===========\nZorder Demo\n===========\n\nThe drawing order of artists is determined by their ``zorder`` attribute, which\nis a floating point number. Artists with higher ``zorder`` are drawn on top.\nYou can change the order for individual artists by setting their ``zorder``.\nThe default value depends on the type of the Artist:\n\n================================================================    =======\nArtist                                                              Z-order\n================================================================    =======\nImages (`.AxesImage`, `.FigureImage`, `.BboxImage`)                 0\n`.Patch`, `.PatchCollection`                                        1\n`.Line2D`, `.LineCollection` (including minor ticks, grid lines)    2\nMajor ticks                                                         2.01\n`.Text` (including axes labels and titles)                          3\n`.Legend`                                                           5\n================================================================    =======\n\nAny call to a plotting method can set a value for the zorder of that particular\nitem explicitly.\n\n.. note::\n\n   `~.axes.Axes.set_axisbelow` and :rc:`axes.axisbelow` are convenient helpers\n   for setting the zorder of ticks and grid lines.\n\nDrawing is done per `~.axes.Axes` at a time. If you have overlapping Axes, all\nelements of the second Axes are drawn on top of the first Axes, irrespective of\ntheir relative zorder.\n\"\"\"",
              "type": "str"
            },
            "type": "sd"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "import",
              "type": "str"
            },
            "type": "kn"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib",
                  "version": "*"
                },
                "value": "matplotlib"
              },
              "type": "Link"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "pyplot"
              },
              "type": "Link"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "as",
              "type": "str"
            },
            "type": "k"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "import",
              "type": "str"
            },
            "type": "kn"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "numpy"
              },
              "type": "Link"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "as",
              "type": "str"
            },
            "type": "k"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "r"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.core.function_base.linspace",
                  "version": "*"
                },
                "value": "linspace"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "0.3",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "1",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "30",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "theta"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.core.function_base.linspace",
                  "version": "*"
                },
                "value": "linspace"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "0",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "4",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": "*",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "pi",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "30",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "r"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "*",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.ufunc",
                  "version": "*"
                },
                "value": "sin"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "theta"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "y"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "r"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "*",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.ufunc",
                  "version": "*"
                },
                "value": "cos"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "theta"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "###############################################################################",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# The following example contains a `.Line2D` created by `~.axes.Axes.plot()`",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# and the dots (a `.PatchCollection`) created by `~.axes.Axes.scatter()`.",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# Hence, by default the dots are below the line (first subplot).",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# In the second subplot, the ``zorder`` is set explicitly to move the dots",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# on top of the line.",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.int",
                  "version": "*"
                },
                "value": "fig"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax1",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax2",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.subplots",
                  "version": "*"
                },
                "value": "subplots"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "1",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "2",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "figsize",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "6",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "3.2",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax1",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "plot",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "y"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "C3",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "lw",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "3",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax1",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "scatter",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "y"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "s",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "120",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax1",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "set_title",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Lines on top of dots",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax2",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "plot",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "y"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "C3",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "lw",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "3",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax2",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "scatter",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "y"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "s",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "120",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "zorder",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "2.5",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "  ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# move dots on top of line",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "ax2",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "set_title",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Dots on top of lines",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.tight_layout",
                  "version": "*"
                },
                "value": "tight_layout"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "###############################################################################",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# Many functions that create a visible object accepts a ``zorder`` parameter.",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# Alternatively, you can call ``set_order()`` on the created object later.",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.core.function_base.linspace",
                  "version": "*"
                },
                "value": "linspace"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "0",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "7.5",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "100",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.RcParams",
                  "version": "*"
                },
                "value": "rcParams"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "[",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "lines.linewidth",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "]",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "5",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.figure",
                  "version": "*"
                },
                "value": "figure"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.plot",
                  "version": "*"
                },
                "value": "plot"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.ufunc",
                  "version": "*"
                },
                "value": "sin"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "label",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "zorder=2",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "zorder",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "2",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "  ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# bottom",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.plot",
                  "version": "*"
                },
                "value": "plot"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy",
                  "version": "*"
                },
                "value": "np"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "numpy",
                  "path": "numpy.ufunc",
                  "version": "*"
                },
                "value": "sin"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "builtins",
                  "path": "builtins.tuple",
                  "version": "*"
                },
                "value": "x"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "+",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "0.5",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "label",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "zorder=3",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "  ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "zorder",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "3",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.axhline",
                  "version": "*"
                },
                "value": "axhline"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "0",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "label",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "zorder=2.5",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "color",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "lightgrey",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "zorder",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "2.5",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.title",
                  "version": "*"
                },
                "value": "title"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Custom order of elements",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "l",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.legend",
                  "version": "*"
                },
                "value": "legend"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "loc",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "upper right",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "l",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "set_zorder",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "2.5",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "  ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "# legend between blue and orange line",
              "type": "str"
            },
            "type": "c1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot",
                  "version": "*"
                },
                "value": "plt"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": {
                "exists": true,
                "kind": "module",
                "reference": {
                  "kind": "module",
                  "module": "matplotlib",
                  "path": "matplotlib.pyplot.show",
                  "version": "*"
                },
                "value": "show"
              },
              "type": "Link"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          }
        ],
        "out": ""
      },
      "type": "Code2"
    },
    {
      "data": {
        "value": {
          "kind": "assets",
          "module": "matplotlib",
          "path": "ex-zorder_demo.py-0.png",
          "version": "3.5.1"
        }
      },
      "type": "Fig"
    },
    {
      "data": {
        "value": {
          "kind": "assets",
          "module": "matplotlib",
          "path": "ex-zorder_demo.py-1.png",
          "version": "3.5.1"
        }
      },
      "type": "Fig"
    }
  ],
  "title": null
}