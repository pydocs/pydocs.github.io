{
  "children": [
    {
      "data": {
        "ce_status": "execed",
        "entries": [
          {
            "link": {
              "data": "\"\"\"\n==========\nSTIX Fonts\n==========\n\nDemonstration of `STIX Fonts <https://www.stixfonts.org/>`_ used in LaTeX\nrendering.\n\"\"\"",
              "type": "str"
            },
            "type": "sd"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "import",
              "type": "str"
            },
            "type": "kn"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "matplotlib",
              "type": "str"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": "pyplot",
              "type": "str"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "as",
              "type": "str"
            },
            "type": "k"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "plt",
              "type": "str"
            },
            "type": "nn"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "circle123",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\"",
              "type": "str"
            },
            "type": "s2"
          },
          {
            "link": {
              "data": "\\N{CIRCLED DIGIT ONE}",
              "type": "str"
            },
            "type": "se"
          },
          {
            "link": {
              "data": "\\N{CIRCLED DIGIT TWO}",
              "type": "str"
            },
            "type": "se"
          },
          {
            "link": {
              "data": "\\N{CIRCLED DIGIT THREE}",
              "type": "str"
            },
            "type": "se"
          },
          {
            "link": {
              "data": "\"",
              "type": "str"
            },
            "type": "s2"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "tests",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "[",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "%s",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathrm",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "%s",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "}",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "%s",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "}$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "%",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "circle123",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "*",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "3",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathsf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Sans ",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Omega}",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathrm",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathsf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Sans ",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Omega}}",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathsf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Sans ",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Omega}}$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathtt",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{Monospace}",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathcal",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{CALLIGRAPHIC}",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbb",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Blackboard",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "pi}$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathrm",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbb",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Blackboard",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "pi}}$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbb",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "Blackboard",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "pi}}$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathfrak",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{Fraktur}",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ";",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathbf",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathfrak",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{Fraktur}",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "}$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "r",
              "type": "str"
            },
            "type": "sa"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "\\",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "mathscr",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "{Script}",
              "type": "str"
            },
            "type": "si"
          },
          {
            "link": {
              "data": "$",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": "'",
              "type": "str"
            },
            "type": "s1"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "]",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "fig",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "plt",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "figure",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "figsize",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "8",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "len",
              "type": "str"
            },
            "type": "nb"
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "tests",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "+",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "2",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "for",
              "type": "str"
            },
            "type": "k"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "i",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "s",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "in",
              "type": "str"
            },
            "type": "ow"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "enumerate",
              "type": "str"
            },
            "type": "nb"
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "tests",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "[",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ":",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ":",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "-",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "1",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": "]",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ":",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "    ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "fig",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "text",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "0",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "i",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "+",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".5",
              "type": "str"
            },
            "type": "mf"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "/",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "len",
              "type": "str"
            },
            "type": "nb"
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "tests",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "s",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ",",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": " ",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "fontsize",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "=",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "32",
              "type": "str"
            },
            "type": "mi"
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "plt",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ".",
              "type": "str"
            },
            "type": "o"
          },
          {
            "link": {
              "data": "show",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "(",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": ")",
              "type": "str"
            },
            "type": ""
          },
          {
            "link": {
              "data": "\n",
              "type": "str"
            },
            "type": ""
          }
        ],
        "out": ""
      },
      "type": "Code2"
    },
    {
      "data": {
        "value": {
          "kind": "assets",
          "module": "matplotlib",
          "path": "ex-stix_fonts_demo.py-0.png",
          "version": "3.5.1"
        }
      },
      "type": "Fig"
    }
  ],
  "title": null
}